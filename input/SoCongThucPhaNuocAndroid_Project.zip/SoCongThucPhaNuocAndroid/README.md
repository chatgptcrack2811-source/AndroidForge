# Sổ Công Thức Pha Nước — Android project

Dự án Android Studio bọc giao diện web vào WebView để tạo ứng dụng Android cài đặt được.

## Build APK
1. Giải nén ZIP.
2. Mở Android Studio → **Open** → chọn thư mục `SoCongThucPhaNuocAndroid`.
3. Chờ Gradle Sync hoàn tất (cần kết nối Internet lần đầu để tải Android Gradle Plugin/SDK nếu máy chưa có).
4. Chọn **Build → Build APK(s)**.
5. APK debug thường nằm ở `app/build/outputs/apk/debug/app-debug.apk`.

## Tính năng
- Ghi, sửa, xoá và tìm công thức.
- Phân loại trà sữa / trà trái cây, yêu thích.
- Tự nhân định lượng theo số ly.
- Dữ liệu lưu cục bộ bằng localStorage của WebView.
- Xuất JSON qua hộp thoại lưu file Android; nhập JSON qua bộ chọn file Android.

## Lưu ý
- Dữ liệu nằm trên thiết bị này; gỡ ứng dụng hoặc xoá dữ liệu ứng dụng có thể làm mất dữ liệu. Hãy xuất file sao lưu.
- Các công thức có sẵn chỉ là ví dụ tham khảo.
